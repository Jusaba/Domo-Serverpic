# Board Options
### CPU Frecuency
| opcion  | valor    |
| :------ | :------- |
| 80 MHz  | xtal=80  |
| 160 Mhz | xtal=160 |
### VTables
| opcion | valor    |
| :----- | :------- |
| Flah   | vt=flash |
| Heap   | vt=heap  |
| IRAM   | vt=iram  |
### Exceptions
| opcion                          | valor              |
| :------------------------------ | :----------------- |
| Legacy (new can return nullptr) | exception=legacy   |
| HeapDisabled (new can abort)    | exception=disabled |
| Enabled                         | exception=enabled  |
### SSL Support
| opcion                                                       | valor     |
| ------------------------------------------------------------ | --------- |
| Legacy (new can return nullptr)All SSL ciphers (most compatible) | ssl=all   |
| HeapDisabled (new can abort)Basic SSL ciphers (lower ROM use) | ssl=basic |

### Reset Method

| opcion                 | valor                    |
| ---------------------- | ------------------------ |
| dtr (aka nodemcu)      | ResetMethod=nodemcu      |
| no dtr (aka ck)        | ResetMethod=ck           |
| Enabledno dtr, no_sync | ResetMethod=nodtr_nosync |

### Crystal Frequency 

| opcion | valor          |
| ------ | -------------- |
| 26 MHz | CrystalFreq=26 |
| 40 MHz | CrystalFreq=40 |

### Flash Frequency 

| opcion | valor        |
| ------ | ------------ |
| 40MHz  | FlashFreq=40 |
| 80MHz  | FlashFreq=80 |
| 20MHz  | FlashFreq=20 |
| 26MHz  | FlashFreq=26 |

### Flash Mode 

| opcion            | valor          |
| ----------------- | -------------- |
| DOUT (compatible) | FlashMode=dout |
| DIO               | FlashMode=dio  |
| QOUT              | FlashMode=qout |
| QIO (fast)        | FlashMode=qio  |

### Flash Size

| opcion                      | valor        |
| --------------------------- | ------------ |
| 1MB (FS:64KB OTA:~470KB)    | eesz=1M64    |
| 1MB (FS:128KB OTA:~438KB)   | eesz=1M128   |
| 1MB (FS:144KB OTA:~430KB)   | eesz=1M144   |
| 1MB (FS:160KB OTA:~422KB)   | eesz=1M160   |
| 1MB (FS:192KB OTA:~406KB)   | eesz=1M192   |
| 1MB (FS:256KB OTA:~374KB)   | eesz=1M256   |
| 1MB (FS:512KB OTA:~246KB)   | eesz=1M512   |
| 1MB (FS:none OTA:~502KB)    | eesz=1M      |
| 2MB (FS:64KB OTA:~992KB)    | eesz=2M64    |
| 2MB (FS:128KB OTA:~960KB)   | eesz=2M128   |
| 2MB (FS:256KB OTA:~896KB)   | eesz=2M256   |
| 2MB (FS:512KB OTA:~768KB)   | eesz=2M512   |
| 2MB (FS:1MB OTA:~512KB)     | eesz=2M1M    |
| 2MB (FS:none OTA:~1019KB)   | eesz=2M      |
| 4MB (FS:2MB OTA:~1019KB)    | eesz=4M2M    |
| 4MB (FS:3MB OTA:~512KB)     | eesz=4M3M    |
| 4MB (FS:1MB OTA:~1019KB)    | eesz=4M1M    |
| 4MB (FS:none OTA:~1019KB)   | eesz=4M      |
| 8MB (FS:6MB OTA:~1019KB)    | eesz=8M6M    |
| 8MB (FS:7MB OTA:~512KB)     | eesz=8M7M    |
| 16MB (FS:14MB OTA:~1019KB)  | eesz=16M14M  |
| 16MB (FS:15MB OTA:~512KB)   | eesz=16M15M  |
| 512KB (FS:32KB OTA:~230KB)  | eesz=512K32  |
| 512KB (FS:64KB OTA:~214KB)  | eesz=512K64  |
| 512KB (FS:128KB OTA:~182KB) | eesz=512K128 |
| 512KB (FS:none OTA:~246KB)  | eesz=512K    |

### Builtin Led

| opcion | valor  |
| ------ | ------ |
| 2      | led=2  |
| 0      | led=0  |
| 1      | led=1  |
| 3      | led=3  |
| 4      | led=4  |
| 5      | led=5  |
| 6      | led=6  |
| 7      | led=7  |
| 8      | led=8  |
| 9      | led=9  |
| 10     | led=10 |
| 11     | led=11 |
| 12     | led=12 |
| 13     | led=13 |
| 14     | led=14 |
| 15     | led=15 |
| 16     | led=16 |

### Espressif FW

| opcion                                | valor              |
| ------------------------------------- | ------------------ |
| nonos-sdk 2.2.1+100 (190703)          | sdk=nonosdk_190703 |
| nonos-sdk 2.2.1+119 (191122)          | sdk=nonosdk_191122 |
| nonos-sdk 2.2.1+113 (191105)          | sdk=nonosdk_191105 |
| nonos-sdk 2.2.1+111 (191024)          | sdk=nonosdk_191024 |
| nonos-sdk 2.2.1 (legacy)              | sdk=nonosdk221     |
| nonos-sdk pre-3 (180626 known issues) | sdk=nonosdk3v0     |

### lwIP Variant

| opcion                            | valor   |
| --------------------------------- | ------- |
| v2 Lower Memory                   | ip=lm2f |
| v2 Higher Bandwidth               | ip=hb2f |
| v2 Lower Memory (no features)     | ip=lm2n |
| v2 Higher Bandwidth (no features) | ip=hb2n |
| v2 IPv6 Lower Memory              | ip=lm6f |
| v2 IPv6 Higher Bandwidth          | ip=hb6f |
| v1.4 Higher Bandwidth             | ip=hb1  |
| v1.4 Compile from source          | ip=src  |

### Debug port

| opcion   | valor        |
| -------- | ------------ |
| Disabled | dbg=Disabled |
| Serial   | dbg=Serial   |
| Serial1  | dbg=Serial1  |

### Debug Level

| opcion                                                       | valor                                                        |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| None                                                         | lvl=None____                                                 |
| SSL                                                          | lvl=SSL                                                      |
| TLS_MEM                                                      | lvl=TLS_MEM                                                  |
| HTTP_CLIENT                                                  | lvl=HTTP_CLIENT                                              |
| HTTP_SERVER                                                  | lvl=HTTP_SERVER                                              |
| SSL+TLS_MEM                                                  | lvl=SSLTLS_MEM                                               |
| SSL+HTTP_CLIENT                                              | lvl=SSLHTTP_CLIENT                                           |
| SSL+HTTP_SERVER                                              | lvl=SSLHTTP_SERVER                                           |
| TLS_MEM+HTTP_CLIENT                                          | lvl=TLS_MEMHTTP_CLIENT                                       |
| TLS_MEM+HTTP_SERVER                                          | lvl=TLS_MEMHTTP_SERVER                                       |
| HTTP_CLIENT+HTTP_SERVER                                      | lvl=HTTP_CLIENTHTTP_SERVER                                   |
| SSL+TLS_MEM+HTTP_CLIENT                                      | lvl=SSLTLS_MEMHTTP_CLIENT                                    |
| SSL+TLS_MEM+HTTP_SERVER                                      | lvl=SSLTLS_MEMHTTP_SERVER                                    |
| SSL+HTTP_CLIENT+HTTP_SERVER                                  | lvl=SSLHTTP_CLIENTHTTP_SERVER                                |
| TLS_MEM+HTTP_CLIENT+HTTP_SERVER                              | lvl=TLS_MEMHTTP_CLIENTHTTP_SERVER                            |
| SSL+TLS_MEM+HTTP_CLIENT+HTTP_SERVER                          | lvl=SSLTLS_MEMHTTP_CLIENTHTTP_SERVER                         |
| CORE                                                         | lvl=CORE                                                     |
| WIFI                                                         | lvl=WIFI                                                     |
| HTTP_UPDATE                                                  | lvl=HTTP_UPDATE                                              |
| UPDATER                                                      | lvl=UPDATER                                                  |
| OTA                                                          | lvl=OTA                                                      |
| OOM                                                          | lvl=OOM                                                      |
| MDNS                                                         | lvl=MDNS                                                     |
| CORE+WIFI+HTTP_UPDATE+UPDATER+OTA+OOM+MDNS                   | lvl=COREWIFIHTTP_UPDATEUPDATEROTAOOMMDNS                     |
| SSL+TLS_MEM+HTTP_CLIENT+HTTP_SERVER+
CORE+WIFI+HTTP_UPDATE+UPDATER+OTA+OOM+MDNS | lvl=SSLTLS_MEMHTTP_CLIENTHTTP_SERVERCOREWIFIHTTP_UPDATEUPDATEROTAOOMMDNS |
| NoAssert-NDEBUG                                              | lvl=NoAssert-NDEBUG                                          |

### Erase Flash

| opcion                 | valor     |
| ---------------------- | --------- |
| Only Sketch            | wipe=none |
| Sketch + WiFi Settings | wipe=sdk  |
| All Flash Contents     | wipe=all  |

### Upload Speed

| opcion  | valor        |
| ------- | ------------ |
| 115200  | baud=115200  |
| 57600   | baud=57600   |
| 230400  | baud=230400  |
| 460800  | baud=460800  |
| 921600  | baud=921600  |
| 3000000 | baud=3000000 |

