# Instalacióm manual de Serverpic V0 🛠️ #

En este documento se describe el procedimeinto para preparar una Raspberry para instalar ServerPic.

En el procedimiento se diferencian tres procesos relativamente independientes. El primero, personaliza la raspberry, le asigan un puerto a ssh, cambia password de acceso, asigna una IP estática,..... es lo que en el indice aparece como configuracion básica. El segundo bloque instala un software que no es necesario para ejecutar Serverpic auque, algunos paquetes si que se utilizarán como complemento a Serverpic, es el apartado denominado Software Basio. Por último, esta el bloque que instala Serverpic propiamente dicho.

En realidad, Serverpic, para funcionar como servidor, lo único que necesita es Java pero para disponer de ciertas funcionalidades se aprovecha de Mysql

A continuación se detalla el índice para instalar Serverpic con algunas aplicaciones que, como se ha comentado, sin ser necesarias, facilitan la administración de la Raspberry.

* 1. [Puesta en marcha](#id1)
    * 1.1. [Instalación del sistema operativo. Puesta en marcha](#id2)
        * 1.1.1. [Descarga del sistema operativo](#id3)
        * 1.1.2. [Grabar el Sistema operativo en SD](#id4)
    * 1.2. [Configuraciones básicas](#id5)
  	    * 1.2.1. [Cambio password](#id6)
        * 1.2.2. [Modificar puerto SSH](#id7)
        * 1.2.3. [Configuración WIFI](#id8)
            * 1.2.3.1. [WIFI en raspberry pi](#id9)	
            * 1.2.3.2. [WIFI en raspberry pi zero](#id10)
   	    * 1.2.4. [Asignación IP estática](#id11)
   	    * 1.2.5. [Actualizar repositorios](#id12)
* 2. [Software Básico](#id13)
    * 2.1. [Instalación de software genérico](#id14)
        * 2.1.1. [Screen](#id15)
   	    * 2.1.2. [SAMBA](#id16)
   	    * 2.1.3. [LAMP](#id17)
            * 2.1.3.1. [Apache](#id18)
            * 2.1.3.2. [PHP](#id19)
            * 2.1.3.3. [Mysql](#id20)
            * 2.1.3.4. [Phpmyadmin](#id21)
            * 2.1.3.5. [Asignacion password a usuario root de mysql](#id22)
            * 2.1.3.6. [Asignacion HOST. Minidyndns](#id23)
        * 2.1.4. [Java](#id24)
    * 2.2. [Instalacion de software especifico](#id25)
   	    * 2.2.1. [ServerPIC](#id26)

[[Vuelta al indice principal|Home]]

# 1. Puesta en marcha<a name="id1"></a>
Se describe en este apartados los pasos a seguir para la puesta en marcha de la Raspberry
## 1.1. Instalación del sistema operativo<a name="id2"></a>
### 1.1.1 Descarga del sistema operativo<a name="id3"></a>
Se debe descargar desde el [Sitio oficial](https://www.raspberrypi.org/downloads/raspbian/)
Se puede descargar la versión de escritorio o la versión LITE. Para este proyecto es aconsejable utilizar una versión sin escritorio para optimizar el espacio ocupado por el SO.
### 1.1.2 Grabar el sistema operativo en SD<a name="id4"></a>
Extraer el fichero imagen y grabarlo en un SD mediante [win32diskimager](https://sourceforge.net/projects/win32diskimager/files/latest/download) o con [etcher](https://www.balena.io/etcher/).
Para poder acceder a la Raspberry por SSH es necesario habilitarlo, la manera más sencilla es añadiendo al direcotrio raiz de la SD preparada en el paso anterior un fichero completamente vacio con el nombre de ssh. Una vez incorporado ese fichero, se debe introducir la SD en la Raspberry y alimentarla para iniciar el proceso de puesta en marcha.
## 1.2 Configuraciones básicas<a name="id5"></a>
### 1.2.1 Cambio password<a name="id6"></a>
Por defecto, la Raspberry tiene un password común para todas ellas, es aconsejable o, mejor dicho, imprescindible cambiar el password del ususario pi.
Antes de nada, partimos de que se ha habilitado ssh y que la Raspberry se ha conectado al router por ethernet, en el caso de la zero, se habrá conectado por wifi tal como se detalla en la sección correspondiente. Conectándonos al router, averiguaremos que dirección IP se le ha asignado a la Raspberry y accederemos a una ventana de comandos mediante ssh. Para esta conexión utilizaremos los parámetros por defecto:
		
    Puerto: 22
    Usuario: pi
    Password: raspberry

Una vez conectados por ssh tecleamos

	sudo passwd

Nos preguntará nuevo pasword y nos pedirá confirmación

Si queremos habilitar el acceso mediante superusuario, teclear:

	sudo passwd root

Escribir y confirmar el password para root

Una vez habilitado el acceso por ssh, podemos habilitarlo/deshabilitarlo tecleando

	sudo raspi-config

Nos aparece una ventana con varias opciones.

Seleccionamos la opción 5.-Interfacing Options 

![HabilitarSSH_1.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/SdrWiqtMTO2z8QTmghx1_HabilitarSSH_1.JPG)

Seleccionamos la opción P2.-SSH 

![HabilitarSSH_2.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/v5xEb18Slquy3donxRtj_HabilitarSSH_2.JPG)

Y pulsamos Yes

![HabilitarSSH_3.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/Jiejv8FnQUmDU1EKwOLq_HabilitarSSH_3.JPG)

Desde esta pantalla de configuración también es posible cambiar el password y otros parámetros de nuestra raspberry.

### 1.2.2 Modificar puerto SSH<a name="id7"></a>
Como se ha dicho, el puerto por defecto para ssh es el 22, si se quiere cambiar, editamos el fichero **/etc/ssh/sshd_config** tecleando:

	sudo nano /etc/ssh/sshd_config
  
modificamos la linea port 22, generalmente aparece comentada con una almohadilla #, borramos dicho carácter, ponemos el nuevo puerto y guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

### 1.2.3 Configuración WIFI<a name="id8"></a>
Para configurar el wifi de la raspberry se debe diferenciar entre Raspberri Pi 3 y Raspberry Pi Zero
#### 1.2.3.1 WIFI en raspberry pi<a name="id9"></a>
Para raspberry pi, se debe editar el ficehro **/etc/network/interfaces**

	sudo nano /etc/network/interfaces
  
Nos aseguramos de que existen las siguientes líneas, si no fuera así, se deben crear

    iface wlan0 inet manual
    wpa-conf /etc/wpa_supplicant/wpa_supplicant.conf
    
Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

Editamos ahora el ficehro **/etc/wpa_supplicant/wpa_supplicant.conf**

    sudo nano /etc/wpa_supplicant/wpa_supplicant.conf
    
Tecleamos la SSID y Password a la que se debe conectar la raspberry

    network={
            ssid="miSSID"
            psk="micontraseña"
            key_mgmt=WPA-PSK        
    }
    
Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

#### 1.2.3.2 WIFI en raspberry pi zero<a name="id10"></a>

En la Zero, la red wifi se habilita en el momento de iniciarla por primera vez grabando en el directorio raiz de la SD donde se encuentra la imagen del SO el fichero **wpa_supplicant.conf**. Al arrancar, el SO se encargará de configurar la red wifi con los datos de ese fichero que debe contener la siguiente información:

    network={
            ssid="miSSID"
            psk="micontraseña"
            key_mgmt=WPA-PSK        
    }

### 1.2.4 Asignación IP estática<a name="id11"></a>

Para poder acceder de forma práctica a la Raspberry por SSH es necesario que disponga de una IP fija, para ello:

Editar el fichero **/etc/dhcpcd.conf** tecleando:

	sudo nano /etc/dhcpcd.conf

Le añadimos las siguientes lineas para asignarle por ejemplo la dirección 192.168.1.20

    interface eth0 
    static ip_address=192.168.1.20/24
    static routers=192.168.1.1
    static domain_name_servers=8.8.8.8
    static domain_search=8.8.4.4
    
Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

### Atención

> Si lo que se quiere configurar es la WLAN, en lugar de interface etho se debe poner interface wlan0

Editar el fichero **/etc/network/interfaces** tecleando:

    sudo nano /etc/network/interfaces
    
Nos aseguramos de que eth0 esta en manual

    iface eth0 inet manual
    
Para Wifi, las lineas seran las siguientes

    iface wlan0 inet manual
    wpa-conf /etc/wpa_supplicant/wpa_supplicant.conf
    
Si es necesario lo modificamos y salvamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

Reiniciamos la Raspberry

    sudo reboot
    
y comprobamos que tiene la dirección ip asignada con

    ifconfig
    
### Atención

> Hay que tener en cuenta que para acceder por SSH, ahora hay una nueva IP y un nuevo puerto de SSH

### 1.2.5 Actualizar repositorios<a name="id12"></a>
Teclear

	sudo apt-get -y update
	        y luego
	sudo apt-get -y upgrade
  
# 2 Software Básico<a name="id13"></a>
Se describe en este apartado la instalación del software en la Raspberry
## 2.1 Instalación de software genérico<a name="id14"></a>
La primera parte del apartado se dedica al software genérico, software que sin ser imprescindible si que es aconsejable tener instalado en la Raspberry
### 2.1.1 Screen<a name="id15"></a>
Cuando desde un terminal SSH se arranca un proceso normalmente, este, 'muere' cuando se cierra el terminal. En muchas ocasiones es deseable mantener el proceso en ejecución aún cerrando el terminal. Una forma de conseguir esto es utilizando Screen. Screen es un gestor de sesiones que permite arrancar un proceso y cerrar el terminal manteniendo el proceso en funcionamiento

Para instalarlo teclear:

	sudo apt-get install screen

Algunos comandos útiles

Para ver las sesiones en marcha

	screen -ls

![Screen_1.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/azSNfOTuQPmSmLPmHQrQ_Screen_1.JPG)

Para crear una sesión, simplemente se escribirá

	screen

realizamos las operaciones que necesitemos en la sesión y para cerrarla tecleamos exit o **ctrl + d**, con esto 'eliminaremos' la sesión, si lo que queremos es cerrarla pero manteniéndola activa saldremos con **Ctrl + a** y acto seguido **Ctrl + d**

Para acceder a una sesión activa lo haremos con el comando **-r** o **-x**

    screen -r 29698.pts-4.raspberrypi
    
Pulsamos intro y accedemos a esa sesión. Como que manejar esos nombres es bastante engorroso, a las sesiones se le puede asignar un nombre más amigable con el comando -S

screen -S ServidorPIC

Ahora el nombre de la sesión es mas manejable


![Screen_2.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/XX8GuiAESAq2G7fdR0dE_Screen_2.JPG)

Ahora para acceder a la sesión teclearemos

    screen -r ServidorPIC
    
Si quisiéramos arrancar una nueva sesión pero sin abrirla usaríamos los comandos -d -m

    screen -d -m -S ServidorPIC
    
Si queremos enviarle comandos a la sesión sin tener que entrar en ella se utiliza el comando -X

    screen -S ServidorPIC -X quit
    
Si lo que queremos es 'matar' la screen, tecleamos

    screen -X -S ServidorPic kill
    
### 2.1.2 SAMBA<a name="id16"></a>
    
samba permite acceder al sistema de ficheros desde otro sistema operativo, normalmente lo utilizaremos para acceder a la estructura de directorios de Raspberry desde nuestro PC con Windows.

Para instalar Samba, lo primero que debemos hacer es instalar los paquetes necesarios en la raspberry

    sudo apt-get install samba samba-common-bin
    
Ahora debemos configurar SAMBA para decirle que carpetas compartir, para ello editaremos el fichero **/etc/samba/smb.conf**

    sudo nano /etc/samba/smb.conf
    
Por defecto Windows crea un grupo de trabajo llamado Workgroup por lo que si estamos utilizando ese grupo lo dejaremos en el fichero de configuración

	#Change this to the workgroup/NT-domain name your Samba server will part of
	workgroup = WORKGROUP

La línea correspondiente a 'wins support' generalmente aparece comentada con una almohadilla #, borramos dicho carácter para habilitar ese valor y lo ponemos en yes.

    # Windows Internet Name Serving Support Section:
    # WINS Support - Tells the NMBD component of Samba to enable its WINS Server
       wins support = yes
Buscamos la línea donde se conceden permisos sobre ficheros y directorios y los cambiamos para asignarles 0777

    # File creation mask is set to 0700 for security reasons. If you want to
    # create files with group=rw permissions, set next parameter to 0775.
    create mask = 0777

    # Directory creation mask is set to 0700 for security reasons. If you want to
    #create dirs. with group=rw permissions, set next parameter to 0775.
    directory mask = 0777
El siguiente paso es buscar un apartado llamado 'Share Definitions' dentro del archivo. Aquí vamos a crear las carpetas que vamos a compartir en red y a configurarlas según nuestras necesidades. En nuestro caso vamos a compartir todo el disco de la raspberry, pondremos lo siguiente

    [pi]
            comment = Users profiles
            path = /
            browseable = yes
            read only = no
Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

El último paso será establecer una contraseña al usuario Pi que nos sera solicitada al entrar en la carpeta de Samba desde la red. Para ello tecleamos:

    sudo smbpasswd -a pi
    
Nos pedirá teclear el password y luego volverlo a teclear para confirmar, una vez hecho nos confirmará que se ha añadido el usuario pi.

Para finalizar, reiniciamos el servicio

    sudo systemctl restart smbd
    sudo systemctl restart nmbd
    
Si se quiere dar acceso a internet, en el router se deberán redireccionar los siguientes puertos a la raspberry

	Puertos tcp (135,139 y 445)
  Puertos udp (137 y 138)
            
Otros comandos samba 

Para desinstalar samba

	sudo apt-get purge --auto-remove samba

Para analizar smb.conf

	testparm
  
### 2.1.3 LAMP<a name="id17"></a>
#### 2.1.3.1 Apache<a name="id18"></a>
Lo primero que haremos será crear y dar permisos al grupo que usa apache por defecto.

	sudo addgroup www-data
  sudo usermod -a -G www-data www-data
    
Hacemos un update de los repositorios

	sudo apt-get update
  sudo apt-get upgrade

Instalamos Apache

	sudo apt-get install apache2
  
Cuando termine la instalacion, se crea una carpeta por defecto donde estan nuestros 'sitios', ubicada en **/var/www**; Para cambiar los permisos poner el comando

    sudo chmod -R 775 /var/www
    
Por defecto, Apache escuchará en el puerto 80, si queremos cambiar el puerto tendremos que editar el fichero **/etc/apache2/ports.conf**

	sudo nano /etc/apache2/ports.conf

y modificamos la línea Listen 80 con el puerto deseado ( Listen 8080 por ejemplo )

Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

Realizamos lo mismo con el fichero **/etc/apache2/sites-enabled/ooo-default.conf**

    sudo nano /etc/apache2/sites-enabled/000-default.conf
    
y modificamos la línea <VirtualHost *:80> con el puerto deseado ( VirtualHost *:8080 por ejemplo )

Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

Con esto queda instalado Apache, ahora solo queda reiniciar el servicio

    sudo /etc/init.d/apache2 restart
    
Estos son algunos comandos que pueden ser utiles para trabajar con el servidor.

	Iniciar el servidor   -> sudo service apache2 start
	Detener el servidor   -> sudo service apache2 stop
	Reiniciar el servidor -> sudo service apache2 restart
	Estado del servidor   -> sudo service apache2 status

#### 2.1.3.2 PHP<a name="id19"></a>

instalamos PHP

	sudo apt-get install php
    
Reiniciamos Apache

	sudo /etc/init.d/apache2 restart

Para probar que PHP se instalo correctamente, creamos un archivo **phpinfo.php** en **/var/www/html**

    sudo nano /var/www/html/phpinfo.php

con el siguiente contenido:

    <?php 
            phpinfo();
    ?>
    
Ahora, desde un navegador accedemos a la dirección/puerto asignados a Apache en la Raspberry, en nuestor caso, suponiendo que hemos puesto la IP estática 192.168.1.20 y el puerto de apache 8080, sería:

	http:\\192.168.1.20:8080\phpinfo.php

Si todo se ha realizado correctamente, el servidor nos mostrará la configuración de PHP

#### 2.1.3.3 Mysql<a name="id20"></a>

Instalamos Mysql

Una vez hemos instalado Apache y php, procedemos a instalar mysql y phpmyAdmin. Teniendo en cuenta que se van a instalar los dos paquetes, vamos a alterar el orden de poner password a mysql

El primer paso que se realizará será activar nuestra interfaz loopback ya que si no lo hacemos nos dará un error al instalar MySQL

	sudo ifup lo

El siguiente paso será instalar mysql

	sudo apt-get install mysql-server mysql-client

Ahora, sin arrancar mysql, dejamos para después de la instalación de phpmyadmin la asignación de password al ususario root de mysql.

Estos son algunos comandos que pueden ser utiles para trabajar con el servidor.

	Inicial el servidor   -> sudo service mysql start
	Detener el servidor   -> sudo service mysql stop
	Reiniciar el servidor -> sudo service mysql restart

#### 2.1.3.4 Phpmyadmin<a name="id21"></a>

Instalamos phpmyadmin

	sudo apt-get install phpmyadmin

Se instalara el programa y nos preguntara que servidor tenemos instalado, seleccionaremos **apache2** ( con un espacio ) y con tabulador vamosa **Ok** y pulsamos **intro**

![phpmyadmin_1.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/I3ZR3K0ZS1y06FZN8Zs2_phpmyadmin_1.JPG)


Luego nos presentara la siguiente pantalla a la que debemos responder **Yes**

![phpmyadmin_2.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/Vj2vvRhJTF2JxowgJPWL_phpmyadmin_2.JPG)


Por último, nos preguntara el password utilizado para mysql y lo dejaremos en blanco pulsando <intro>

![phpmyadmin_3.JPG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/WTArV7B4TGOKjgNZQIq7_phpmyadmin_3.JPG)

Una vez instalado todo el paquete editaremos el fichero **/etc/apache2/apache2.conf**

	sudo nano /etc/apache2/apache2.conf
    
Le añadimos como última línea el siguiente texto

	Include /etc/phpmyadmin/apache.conf

Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

Editamos el fichero /etc/php/7.0/apache2/php.ini

	sudo nano /etc/php/7.0/apache2/php.ini

Descomentamos la linea

	extension=msql.so

que se encuentra en la seccion **Dynamics Extensions**

Guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

### Atención
>  El path donde se encuentra **php.ini** puede cambiar en funcion de la versión de php instalada. El path detallado es para PHP 7, para PHP 5 el path sería **/etc/php5/apache2/php.ini**

Ponemos en marcha el servidor mysql con el comando

	sudo service mysql restart

Reiniciamos Apache

	sudo service apache2 restart

Ya podemos acceder a PhpMyAdmin en la dirección de la Raspberry. En este caso seria

    http://192.168.1.20:8080/phpmyadmin/   
    
#### 2.1.3.4 Asignacion password a usuario root de mysql<a name="id22"></a>

Una vez instalado mysql y phpmyadmin, se debe asignar password al ususario root de mysql, para ello, se debe entrar en el servidor sin clave

	sudo mysql -u root

A la respuesta para introducir comandos en mysql se le debe dar el siguiente comando para establecer contraseña al administrador

	grant all privileges on *.* to root@localhost identified by 'XXXXXXX' with grant option;

Siendo XXXXXXX el password que se desea para el usuario root

Luego teclear

    flush privileges;
    
Por último teclear **'quit'** para salir del servidor mysql

Para verificar que la instalación quedo correcta, accedemos a mysql de la siguiete forma

	sudo mysql -uroot -p

Nos pedirá la contraseña y nos dará acceso a la consola Mysql. con **Ctrl + Z** saldremos de ella
#### 2.1.3.5 Asignacion HOST. Minidyndns<a name="id23"></a>
Vamos a instalar un cliente de minidyndns para asignar un nombre de host del dominio **jusaba.es**
Supongamos que queemos asignar a nuustro host el nombre **mihost.jusaba.es**, antes de nada, se debe dar de alta en los servidores dns **serverpic.com** y **serverpic.cloud**, una vez dado de alta pasamos a la instalación del cliente.
Partimos de que el equipo tiene instalado **Python 2.7**, cosa que podemos comprobar escribiendo

	python -V
  
Con python 2.t instalado, creamos un directorio **dns** donde crearemos los ficheros necesarios

	cd /home/pi
	mkdir dns
	cd dns

Ahora añadiremos a python el paquete **requests*

	sudo apt-get install python-pip
	pip install requests

Creamos el fichero **Actualiza.dns** con el codigo python para ir actualizando la ip en los servidores dns ( como se dijo anteriormente, antes **mihost** ha tenido que ser dado de alta en los servidores dns )

	import requests
	from requests.auth import HTTPBasicAuth
	requests.get('http://serverpic.cloud:8001', auth=HTTPBasicAuth('mihost', 'JUSABA2408'))
	requests.get('http://serverpic.com:8001', auth=HTTPBasicAuth('mihost', 'JUSABA2408'))

Ahora ya solo queda ejecutar ese códifo de forma periodica, para eso, nos apoyamos en cron de la máquina.

editamos el fichero de cron

	crontab -e
  
Añadimos la línea 

	*/1 * * * * python /home/pi/dns/ActualizaDNS.py
  
Esto hará que se refresque la información en los servidores dns cada minuto

Si hemos utilizado el editor nano en crontab, para guardar los cambios y cerrar el fichero se procede como siempre **Ctrl + O** **Ctrl + X** y habremos finalizado el proceso de instalación del cliente minidyndns


### 2.1.4 JAVA<a name="id24"></a>

Instalamos Java

Lo ideal sería instalar la ultima versión, a la hora de realizar este documento, la ultima version era oracle-java8-jdk.

    sudo apt-get update && sudo apt-get install oracle-java8-jdk

Nos aseguramos de que se ha instalado viendo la versión

    sudo java -version
    
Posiblemente, cuando se lea este documento, la versión de Java es muy posterior a la 8, es imposible predecir si Serverpic funcionará o no con una nueva versión de Java, lo que es seguro es que con la que se referencia eneste documento, Serverpic fucnion aperfectamente.

# 2 Software específico<a name="id25"></a>
En esta sección, se va a describir la instalación del servidor
### 2.2.1 ServerPIC<a name="id26"></a>
Para intalar Serverpic, se ha preparado un paquete deb que lo instala como servicio, para descargarlo se emplearán los siguientes comando

	cd /home/pi
	wget https://www.dropbox.com/s/kc7d01ibxshdtob/Serverpic.deb
  
Una vez descargado, lo descompimiremos

	sudo dpkg -i ServerPic.deb
  
Por defecto el servidor escuchara en el puerto 2001, podemos cambiar ese puerto editando dos líneas del ficher o** /usr/local/bin/serverpic.s**h con

	sudo nano /usr/local/bin/serverpic.sh

Cambiar el puerto 2001 por el deseado en las dos líneas donde aparece y guardar los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

Ya tenemos el programa y el servicio creado, ahora crearemos las tablas en mysql, se nos pedira el password del usuario root de mysql ( En esta descripcion se utilizo el password XXXXXXX )

	mysql -u root  -p < ServerPic.sql

Con el paso anterior se crean las tablas necesarias para ServerPic y un usuario para acceder a esas tablas. El usuario creado para acceso del servidor a mysql es <b>jusaba</b> y el password <b>JuSaBa2408</b>

Con el paso anterior, se harán creado todas las tablas necesarias para Serverpic

### Atención

> Esta versión de ServerPic no permite cambiar el usuario y password de acceso a mysql

Por último vamos a activar el servicio y lo vamos a arrancar

	sudo systemctl enable serverpic.service
	sudo systemctl daemon-reload
	sudo systemctl start serverpic.service

Para ver la actividad del servidor se crea un fichero log donde se vuelca la actividad. El fichero se encuentra en **/home/pi/ServerPic** y su nombre es **serverpic.log**

Para visualizar el fichero, en ese directorio teclear

	tail -f serverpic.log  
  
Si no queremos escribir tanto cada vez que queremos visualizar la actividad del servidor podemos crear un alias

	cd /home/pi
	touch ~/.bash_aliases
	sudo nano ~/.bash_aliases

Escribir en ese fichero la línea

	alias serverpiclog='tail -f /home/pi/ServerPic/serverpic.log'


Como siempre, guardamos los cambios pulsando **Ctrl + O** y salimos con **Ctrl + X**

Ahora, siempre que el usuario pi quiera ver la actividad, tan solo se debe teclear

	serverpiclog

Cuando queramos abandonar la visualizacion, pulsar **Ctrl + Z**

Llegados a este punto, hemos finalizado la Instalación manual de Serverpic, en el seguiente apartado se describe como realizar la [[Instalación automática|Serverpic/InstalacionAutomatica]].
 


  

  
  