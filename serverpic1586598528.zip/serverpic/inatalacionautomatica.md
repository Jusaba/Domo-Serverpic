# InatalacionAutomatica
Para llevar a cabo la instalación automática en una Raspberry, en /home/pi descargaremos los dicheros **Instalacion.sh** y **configuracion**

	wget http://serverpic.cloud:80/Instalacion/Instalacion.sh
	wget http://serverpic.cloud:80/Instalacion/configuracion
  
**Instalación.sh** es el fichero bash que se encarga de todo el proceso de instalación personalizado seg´n los datos contenidos en **configuracion**

Es necesario modificar el fichero **configuracion** con los datos que deseamos

	nano configuracion
  
Ese fichero contiene todos los parametros utilizados en la instalación manual, tan solo hay que cambiarlos para personalizar nuestra instalación. 
El fichero contiene descripción de los distintos apartados de configuración.
Una vez realizados todos los cambios deseados los guardamos  pulsando **Ctrl + O** y salimos con **Ctrl + X**
  