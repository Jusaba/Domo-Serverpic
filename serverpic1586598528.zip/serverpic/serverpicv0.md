# Serverpic V0 📋 <a name="id1"></a>

Como se comentó, **no se aconseja instalar esta versión**, se mantiene la descripción a titulo ilustrativo. Personalmente, cuando empece con esto, no tenía ni idea de Linux ni de lo que era una Raspberry y tuve que dedicar muchas horas para poder instalar adecuadamente el servidor en una Raspberry, con la descripción de la instalación de esta versión, pretendo documentar todo lo que aprendí en su día y, que seguro que de alguna forma u otra seguirá siendo útil para seguir trabajando con Linux.

Antes de tratar la instalación, relacionamos las funcionalidades que ofrece esta versión de Serverpic.

## Funcionalidades de Serverpic V0 📋 <a name="id2"></a>

Como se adelantaba en el apartado [[Serverpic|Serverpic/Serverpic]], el servidor ofrece una serie de funcionalidades a los clientes conectados.

Sin duda, la funcionalidad fundamental es **mensaje** que permite, enviar mensajes de un cliente a otro, entendiendo como clientes dispositivos y terminales, de esta dorma, un terminal le puede mandar un mensaje a un dispositivo y este, se encargara de actuar en consecuencia.

Se puede decir que Serverpic se creo unicamente para esa funcionalidad pero, con el tiempo, surgieron nuevas necesidades y se fueron creando nuevas funcionalidades que se realcionan a continuación:
 

	hora.-      Responde la hora
	mensaje.- 	Envia un mensaje a un cliente. El cliente recibe el texto del mensaje precedido por el 		      remitente
		    			Julian manda      mensaje-:-Pepe-:-Hola
		    			Pepe recibe       Julian-:-Hola
	sms.-       manda un sms. Esto utilizaba una cuenta de freedompop, ya no sepuede utilizar
		    			sms-:-Destinatario-:-Texto
	mail.-      Envia un mail
		    			mail-:-Destinatario-:-Asunto-:-Texto
		    			Esta funcionalidad precisa configurar el correo en el codigo fuente del servidor por	    			tanto
	push.-      Envia un push a un usuarios concreto, esta función no se puede configurar
	save.-    	Guarada una variable para el usuario actual en el servidor
						Julian manda 		save-:-estado-:-1 
				En el servidor se guarda la varable estado con el valor 1 para el usuario Julian
	load.- 		Recupera una variable almacenada en el servidor
						Julian manda 		load-:-estado 
				el servidor responde  '1'				  


## Instalación de Serverpic V0 🛠️ <a name="id3"></a>

La primera instalación de Serverpic, fué totalmente manual, instalando paquete a paquete, abriendo puerto ssh, asignanodo Ip estatica a Raspberry, configurando el Wifi e instalando software que, sin ser necesario para Serverpic, ayudará a la administración y mantenimiento del sistema y por último, la instalación de Java y el propio Serverpic. La descripción de esta instalación, sin duda es una joya para todo aquel que se quiera introducir en Linux y Raspberry.

La instalación manual, cuando se tiene que repetir unas cuants veces, se hace muy pesada y engorrosa por lo que, para facilitar la instalaión, se genero un **bash** que instalaba todos los paquetes personalizándolos con los datos registrados en fichero de configuración. Este sistema, mucho más práctico que el manual pero no aporta contenido formativo.

Segun lo dicho, disponemos de dos opciones de instalación. 

[[Instalación manual|Serverpic/InstalacionManual]]
[[Instalación automática|Serverpic/InstalacionAutomatica]]

Lo que se detalla en esos enlaces no tiene por que ser lo más correcto, es más, soy consciente de que cometo errores, mis conocimientos de Linux y Raspberry siguen siendo realmente escasos, prácticamente nulos y toda la preparación la he realizado por consejos y aportaciones de terceros y, sobre todo, por horas de dedicación y ganas de sacar esto adelante.

## Ejecución de Serverpic V0 ⚙️ <a name="id4"></a>

Ya tenemos instalado Serverpic, ahora debemos arrancarlo.

Por defecto, Serverpic opera en el puerto 2001 aunque tal como se ha explicado en los apartados de instalación, es posible cambiar ese puerto.

Como se instaló como servicio, las ordenar para arrancarlo/pararlo son las siguientes:

	sudo service serverpic start
	sudo service serverpic stop
	sudo service serverpic restart

Ahora, supongamos que la raspberry tiene asignada la IP 192.168.1.12 y el puerto 1201, para acceder al servidor, desde un terminal linux podemos teclear

	nc 192.168.1.12 1201
  
El servidor nos respondera **CONECTADO**, ahora le ponemos el nombre con el que queremos operar en el sistema, por ejemplo **Julian**, despues de pulsar **Intro**, recibiremos del servidor el texto **Registrado**, desde ese momento, el cliente **Julian** forma parte del sistema y esta en disposición de mandar/recibir mensajes.

Si se pretende conectar desde **putty** tendremos que seleccionar una conexión **Raw** e introducir los datos de conexió.

<img class="center" src="https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/xOiaZ2RcQZecSMqtXgb9_Putty_1.JPG">