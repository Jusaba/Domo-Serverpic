# Instalacióm automática de Serverpic V0 🛠️ #
 Par ala instalación automática, partimos de que tenemos la Raspberry con SO y con SSH habilitado, nos hemos conectado al router y hemos averiguago la IP de la Raspberry. Nos conectamos a ella con los datos de conexión por defecto.
 		
    Puerto: 22
    Usuario: pi
    Password: raspberry

Ahora,  en /home/pi descargaremos los dicheros **Instalacion.sh** y **configuracion**

	cd /home/pi
	wget https://www.dropbox.com/s/sog6r6qw7rmg53f/Instalacion.sh
	wget https://www.dropbox.com/s/k78qy95ja3nnt2q/configuracion

  
**Instalación.sh** es el fichero bash que se encarga de todo el proceso de instalación personalizado según los datos contenidos en **configuracion**. Es aconsejable echar un vistazo al fichero, es posible que con nuevas versiones delos paquetes software, este instalado podría falla pero, con un poco de esfuerzo se podría modificar parar solucionar esos problemas de instalación 

El fichero **configuracion** se debe editar con los datos con los que precisamos para nuestra instalación 

	nano configuracion
  
Ese fichero contiene todos los parametros utilizados en la instalación manual, tan solo hay que cambiarlos para personalizar nuestra instalación. 
El fichero contiene descripción de los distintos apartados de configuración.
Una vez realizados todos los cambios deseados los guardamos  pulsando **Ctrl + O** y salimos con **Ctrl + X**

A continuación se muestra el contenido del fichero **configuración** con los parametros por defecto.
Las líneas que empiezan con **#** son comentarios que explican brevemente cada uno de los parametros. Los parametros a modificar se encuentran en las líneas que no empiezan por **#** 
```  
#----------------------------------------------------------
#Raspberry
#Cambia el password de la raspberry
#Si se quita esta linea, se mantendra el password existente
#----------------------------------------------------------
PasswordRasp=Serverpic2408
#----------------------------------------------------------
#SSH
#Cambia el puerto ssh
#Si se quita esta linea, se mantendra el puerto existente
#----------------------------------------------------------
PortSSH=1222
#----------------------------------------------------------
# Red STA 
# Este modo es STA, tanto etho como wlan0 se pueden conectar
# a una red existente
# Si se omite NombreSSID o PasswordSSID no se modifica la
# SSID existente en la raspberry
# Si se pone una direccion en IPETH0, se pondra una ip 
# estatica en eth0. Si se omite se mantendra 
# la configuracion por defecto para eth0
# Si se pone una direccion en IPWLAN0, se pondra una ip 
# estatica en wlan. Si se omite se mantendra 
# la configuracion por defecto para wlan0
# NO SE COMPRUEBAN POSIBLES ERRORES DE ASIGNACION
# LA RED DEBE SER 192.168.1.X
#----------------------------------------------------------
ModoRed=STA
NombreSSID=MiWifi
PasswordSSID=MiPassword
IPETH0=192.168.1.12
IPWLAN0=192.168.1.22
#----------------------------------------------------------
# Red AP 
# Es este modo, wlan se comporta como AP, eth0 se puede
# conectar a una red existente 
# Si se pone una direccion en IPETH0, se pondra una ip 
# estatica en eth0.
# Es necesaria una direccion para IPWLAN0. Si se omite 
# no se pondra en modo AP  
# NO SE COMPRUEBAN POSIBLES ERRORES DE ASIGNACION
# LA RED eth0 DEBE SER 192.168.1.X
#----------------------------------------------------------
ModoRed=AP
IPETH0=192.168.1.12
IPWLAN0=192.168.2.1
NombreSSID=MiSSID
PasswordSSID=MiPassAP
#----------------------------------------------------------
# Screen
# Instala screen, si se omite la linea no se instala
#----------------------------------------------------------
Screen=Si
#----------------------------------------------------------
# Samba
# Instala samba son el password indicado para el susario pi,
# si se omite la linea no se instala
#----------------------------------------------------------
PasswordSamba=Serverpic2408
#----------------------------------------------------------
# Apache
# Instala apache el pueto indicado, si se omite la linea 
# Apache=Si, no se instala, si se omite la linea PortApache
# no se modifica el puerto utilizado por defecto
#----------------------------------------------------------
Apache=Si
PortApache=1280
#----------------------------------------------------------
# PHP
# Instala php, si se omite la linea no se instala
#----------------------------------------------------------
PHP=Si
#----------------------------------------------------------
# Mysql
# Instala mysql, si se omite la linea Mysql=Si, no se instala
# Si se omite la linea de PasswordRootMysql, se pone el 
# password por defecto que es Jusaba2408?
#----------------------------------------------------------
Mysql=Si
PasswordRootMysql=Serverpic2408
#----------------------------------------------------------
# PHPMyAdmin
# Instala phpmyadmin, si se omite la linea no se instala
#----------------------------------------------------------
PhpMyAdmin=Si
#----------------------------------------------------------
# Java
# Se instala java
# Por defecto intenta instalar la version oracle-java8-jdk
# Si se desea otra version se debe modificar la linea 
# VersionJava
#----------------------------------------------------------
Java=Si
VersionJava=oracle-java8-jdk
#----------------------------------------------------------
# ServerPic
# Instala ServerPic escuchando en puerto PuertoServerPic
# Si se omite la linea ServerPic=Si, no se isntala
# si se omite la linea PuertoServerPic, el servidor escucha
# en puerto 2001
#----------------------------------------------------------
ServerPic=Si
PuertoServerPic=1201
VersionJava=oracle-java8-jdk
#----------------------------------------------------------
# WebSocket
# Instala WebSocket escuchando en puerto PuertoServerPic + 1
# Si se omite la linea WebSocket=Si, no se isntala
# si se omite la linea PuertoServerPic, el servidor escucha
# en puerto 2002
#----------------------------------------------------------
WebSocket=Si
#----------------------------------------------------------
# HomeKit
# Instala HAP-Node para emular HomekKit 
# Si se omite la linea Homekit=Si, no se isntala
#----------------------------------------------------------
HomeKit=Si
#----------------------------------------------------------
# DynDns
# Instala DynDNS con los datos de acceso 
# Si falta algun dato, no se instala
# NO SE COMPRUEBAN ERRORES
#----------------------------------------------------------
UsuarioDynDns=JUSABA
PasswordDynDns=ROMEAR
DominioDynDns=lleida.gotdns.com
#----------------------------------------------------------
# ownCloud
# Se instala ownCloud
# Si se omite lal inea ownCloud=Si o falta usuario o password, no se instala
# Si se incluye en PathownCloudData el acceso a un disco de red
# se almacenaran alli los datos, en caso contrario se hara
# una instalacion basica.
#----------------------------------------------------------
ownCloud=Si
PathownCloudData://192.168.1.2/share /Dir_ownCloud cifs ,defaults,uid=www-data,gid=www-data,user=admin,password=passwordadmin,file_mode=0770,dir_mode=0770 0 0
UsuariomysqlownCloud=usuario1
PasswordmysqlownCloud=Serverpic2408
#----------------------------------------------------------
# minidyndns
# Se instala un cliente para minidyndns
# Si se omite lal inea ownCloud=Si o falta el subdominio  no se instala
# para que funcione, es necesario estar registrado en el servidor minidyndns 
# en serverpic.cloud y serverpic.com
# El password de la cuenta en los servidores debe ser JUSABA2408
#----------------------------------------------------------
MiniDynDNS=Si
SubdominioMiniDynDNS=lleida
```