# Serverpic 📋
ServerPic

ServerPic es un servidor realizado en Java que permite la conexión de clientes usando sockets. Como se describió en el [[capítulo anterior|Serverpic/Historia]], Serverpic es un chat de modulos/clientes conectados a el mediante sockets, Serverpic hace de intermediario y serán los dispositivos a el conectados los que deben decidir que hacer con la información que reciben de otros módulos a traves de Serverpic. 

El servidor lo desarrolló Oscar hace ya unos cuantos años. La versión inicial, aunque resultó ser muy estable y cumplió sobradamente con los objetivos para los que fue diseñado, tenía ciertas limitaciones, su ampliación era dificultosa y era un servidor único para la instalación a la que debía dar servicio. Aunque el servidor podía ubicarse fuera de la instalación que se deseaba domotizar, al ser único, la fiabilidad del sistema quedaba condicionada por la fiabilidad del servidor. En la práctica, para instalar Serverpic, utilizamos una Raspberry en cada instalación que queriamos domotizar.

Actualmente se esta utilizando una nueva versión mucho mas flexible que la anterior. Además de poder funcionar como su antecesor, puede funcionar como parte de una red de servidores en trabajo compartido aportando de esta forma seguridad frente al uso de un solo servidor.  

Cualquier dispositivo capaz de abrir un socket se puede conectar al servidor e interactuar con el

Cuando un Cliente se conecta a ServerPic, este le envía el texto <b>CONECTADO</b>, el Cliente, cuando recibe este texto le debe responder al servidor con el nombre de Cliente, este nombre será su identificador en el sistema. Una vez el Cliente envía el nombre al Servidor, si todo es correcto, este le responde con el texto <b>Registrado</b>, a partir de ese momento, el Cliente forma parte del sistema y puede interactuar con el.

En la siguiente imagen se observa una sesión de putty abierta con el servidor con el nombre de Julian, en azul `habla`el servidor, en amarillo lo hace el cliente.


![ConexionaServerPic.PNG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/uKCsYA4rSLqPKG9pXzpm_ConexionaServerPic.PNG)


Los Clientes, una vez conectados tienen acceso a una serie de funcionalidades que les ofrece el Servidor, estas funcionalidades se han ido ampliando, modificando y sustituyendo en función de las necesidades que se han ido presentando.

La funcionalidad que más se va a utilizar es **mensaje**
Si el Cliente **Julian** quiere mandar un saludo al Cliente **Pepe**, **Julian** mandará lo siguiente

```
mensaje-:-Pepe-:-Hola Pepe, como estas?
```

**Pepe** recibirá el saludo precedido por el remitente

```
Julian-:-Hola Pepe, como estas?
```

En la siguiente imagen se observa ese dialogo entre dos Clientes conectados a ServerPic.
También se observa como el Cliente **Julian** manda el comando <b>Hora</b> al servidor y este le responde o, como **Julian**, manda el texto <b>Latido</b> al Servidor y este le responde <b>Ok</b>. 

![Dialogo.PNG](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/3qbsDH2eSRaKK4i8SiJc_Dialogo.PNG)

Como se dijo, un Cliente podrá ser cualquier cosa capaz de abrir un socket. Entre 'cualquier cosa' se contemplan los sensores y actuadores por un lado y por otro los ordenadores, tablets, teléfonos que abrirán socket en el Servidor mediante putty, php, Javascript... para hacer de interfaces del sistema.

Un fucnionamiento básico sería el siguiente, supongamos que tenemos un dispositivo que se ha conectado a Serverpic con el identificativo **Luz** y por otro lado, una sesión putty desde un ordenador con el identificativo **Julian**, si **Julian** manda a Serverpic el texto **mensaje-:-Luz-:-On** el dispositivo **Luz** recibirá el texto **Julian-:-On**, ahora el dispositivo debe ser capaz de separar la cadena recibida para tener por un lado el remitente y por otro la orden, con esa orden **Luz** actuará un relé que se encargará de encender la bombilla conectada al dispositivo.

Como se ha comentado anteriormente, existe una versión inicial del servidor (V0) y una versión posterior (V1) con muchas más prestaciones.

Para instalar Serverpic en una CPU hay que distinguir entre la distintas versiones.

No se recomienda instalar la V0 por que no va a evolucionar más, se considera obsoleta y es posible que con el tiempo deje de funcionar si la CPU  se actualiza con nuevo software, Serverpic V0 sigue siendo estable y funcional por lo que, aunque solo sea con caracter ilustrativo,  se mantiene la descripción de la instalación de esta versión.

### Atención

> La versión 0 no va a seguir evolucionando. Se desaconseja su instalación

Pasamos pues al proceso de instalación de Serverpic diferenciando entre la V0 y la V1 según el siguiente índice:

- [[Serverpic V0|Serverpic/ServerpicV0#id1]]
	- [[Funcionalidades de Serverpic V0|Serverpic/ServerpicV0#id2]]
	- [[Instalación de Serverpic V0|Serverpic/ServerpicV0#id3]]
  	- [[Instalación Manual de Serverpic V0|Serverpic/InstalacionManual]]
    - [[Instalación Automática de Serverpic V0|Serverpic/InstalacionAutomatica]]
	- [[Ejecución de Serverpic V0|Serverpic/ServerpicV0#id4]]

- [[Serverpic V1|Serverpic/ServerpicV1#id2]]
	- [[Principio de funcionamiento de Serverpic V1 en modo multiservidor|Serverpic/ServerpicV1#id2]]
	- [[Funcionalidades de Serverpic V1|Serverpic/ServerpicV1#id3]]
	- [[Instalación de Serverpic V1|Serverpic/ServerpicV1#id4]]
  	- [[Instalación manual de Serverpic V1 sin Docker|Serverpic/ServerpicV1#id5]]
  	- [[Instalación manual de Serverpic V1 con Docker|Serverpic/ServerpicV1#id6]]    
  	- [[Instalación automática de Serverpic V1|Serverpic/ServerpicV1#id7]]        
	- [[Ejecución de Serverpic V1|Serverpic/ServerpicV1#id8]]
  	- [[Ejecución de Serverpic V1 sin Docker|Serverpic/ServerpicV1#id9]]        
  	- [[Ejecución de Serverpic V1 con Docker|Serverpic/ServerpicV1#id10]]         