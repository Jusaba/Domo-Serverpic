###### 1.- Un poco de historia
 

En realidad este proyecto se inició hace ya unos cuantos años
Durante muchos años,  mis obligaciones profesionales me tuvieron apartado de la electrónica, programación y cacharreria en general.

En la etapa universitaria de Oscar, mi hijo, me vi en la necesidad de 'reengancharme' a la electrónica para asesorarle en sus estudios y un buen día nos planteamos la podsibilidad de telecontrolar distintos dispositivos del hogar con electrónica diseñada por nosotros para poderla personalizar a nuestras necesidades y para que resultara lo mas económica posible. El aportaba programación y tecnologías actuales y yo algo de conocimientos de electrónica y experiencia.

En esa época, todavía no se comercializaba el ESP8266, los primeros intentos los realizamos con el modulo RN-171, un buen dispositivo pero excesivamente caro para utilizarlo de forma masiva en un sistema.
<img class="center" src="https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/P4kwo2FfTNqpQH9hxWuu_RN-171.jpg">

El precio del RN-171 nos hizo buscar dispositivos que fueran mas económicos y, descubrimos y probamos con éxito el HLK-RM04 de Hi-Link: Este transceptor WIFI es relativamente pequeño  pero necesitaba un microcontrolador para poderlo gestionar.

Diseñamos una placa con el PIC 18F2550 y conseguimos unos resultados gratificantes aunque el dispositivo final era algo voluminoso por que, a la placa ( 50 x 50 mm ), se le debía añadir una fuente de alimentación.

Es un modulo con muchas posibilidades, además de WIFI gestiona también puertos Ethernet, incluye una web de configuración sin embargo no conseguimos hacerlo lo suficientemente reducido para nuestras necesidades.
<img class="center" src="https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/baWquweWTIO8u7PnFtTy_HLK-RM04.jpg" style="zoom:50%;">
Nos pusimos a buscar soluciones que nos permitieran diseñar dispositivos de control domótico mas pequeños, nos encontramos entonces con el modulo Linkit 7681 de Meidatec Labs.
<img class="center" src="https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/ab2BSz9bQxqYmSmRF29g_Linkit7681.jpg">
Un módulo de reducidas dimensiones y lo mas importante es que dentro del mismo se incluye un microcontrolador con varios pines de  Entradas/Salidas. Parecía la solución ideal

Mediatek Labs ofrece para este dispositivo una placa de desarrollo y un SDK para su programación. Los resultados fueron también satisfactorios.

Por aquella época, Oscar, que hasta ese momento me había ayudado y, en muchas ocasiones instruido , por circunstancias de la vida empezó a desligarse del diseño electrónco.

Me quedé solo con el módulo Linkit 7681, dediqué muchas horas al estudio de este dispositivo, diseñé una placa de aplicación con la fuente de alimentación integrada, el tamaño final era adecuado sin embargo, para mi gusto, la programación en C era bastante farragosa y no supe hacerlo todo lo flexibe que hubiera deseado aunque, la realidad. es que yo tenía muy poca idea de C y ya no podía contar con la ayuda de Oscar.

Al mismo tiempo que dedicaba esfuerzo al modulo Linkit 7681 circulaba ya de forma masiva el ESP8266. Al principio era reacio a utilizar ese módulo, era volver a invertir un montón de horas en otros dispositivo del que no terminaba de ver todas sus virtudes.

El primer contacto que tuve con el ESP8266 modelo EP-01 fue utilizándolo con comandos AT, era un módulo pequeño pero volvia a necesitar un micro por lo que se descarté esa posibilidad ya que también existía la posibilidad de acceder al microcontrolador interno mediante lenguaje LUA. 
<img class="center" src="https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/iVs90p1zQyGJsRBVYiKy_Esp8266.png">
LUA parecía bastante asequible para utilizaciones básicas pero no dejaba de ser un nuevo lenguaje que necesitaba sus horas de aprendizaje. 

Las primeras pruebas realizadas con los distintos módulos los conectabamos a la red wifi doméstica y comunicabamos con ellos a través de su IP. 

Desde un terminal, nos conectabamos a un modulo conociendo su IP y le mandabamos mensajes que el módulo analizaba y actuaba en consecuencia. Este modo de telecontrol estaba bien para un dispositivo pero no era adecuado para un sistema que se pretendía telecontrolar incluso fuera del hogar. 

Para poder telecontrolar un sistema con varios módulos, Oscar creó ServerPic. Los primeros módulos para los que se trabajo fueron los basados en HLK-RM04 y Pic, de ahí el  nombre. ServerPic permite la conexión entre distintos módulos y la comunicación entre ellos sin tener la necesidad de conocer sus IP para poderlos comandar. 

ServerPic, al igual que los módulos Wifi, se conectan a la SSID de la red doméstica, posteriormente, cada módulo Wifi se conecta a ServerPic con un nombre individualizado a través de esa SSID. Ese nombre será el que se utilizará cuando nos queramos dirigir a un módulo concreto o, cuando otro,  requiera su intervención.  Serverpic en definitiva, crea un 'chat' entre todos los módulos/clientes conectados a él sin necesidad de conocer las Ip's.

<img class="center" src="https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/JJpkzSWnTRyy0PctbG82_Sistema%20Serverpic.png" style="zoom:70%;">

Somos conscientes de que existen herramientas populares ( MQT por ejemplo ) que hacen algo similar a ServerPic pero se ha optado por esta opción por que es propia, se puede personalizar, ampliar según necesidades y es compatible con cualquier terminal que pueda abrir un socket.

A todo esto, personalmente, siempre habia esquivado el mundo Arduino, historicamente había utilizado los Pics de Microchip, tenía abundante documentación, equipos de desarrollo y bastante conocimiento sobre ellos, los Pic cubrían sobradamente mis necesidades y no me apetecía embarcarme en otras plataformas. 

Las circunstancias y la casualidad hicieron que al final sucumbiera y me apuntara a un curso de Arduino junt oa a Pepe, compañero de trabajo con el que comparto aficiones. El curso me permitió conocer las posibilidades que ofrecía esta popular plataforma sin renunciar a mis queridos Pic.

Acabado el curso de Arduino.... se produjo el milagro, descubrímos que era posible utilizar los módulos ESP8266 como si fueran un Arduino. Durante un curso académico, junto a Pepe, aprendímos lo suficiente para empezar a defendernos con Arduino y ese conocimiento lo podíamos trasladar al ESP8266 con poco esfuerzo. Adjudicamos al ESP8266 la responsabilidad de ser el elemento básico de los dispositivos de nuestro sistema domótico.



El siguiente paso es continuar con la descripción de [[Serverpic|Serverpic/Serverpic]]