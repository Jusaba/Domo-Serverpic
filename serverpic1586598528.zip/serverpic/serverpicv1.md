# Serverpic V1 📋 <a name="id1"></a>

En este apartado  seva a tratar la última versión de Serverpic.

La versión V1, respecto a la V0, lo único que conserva en el objetivo del servidor, internamente es totalmente distinto y la filosofía de funcionamiento no tiene nada que ver.

Como se explico en la página [[<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Serverpic</font></font>|Serverpic/Serverpic]], el hardware para la V0 se dedicaba en exclusiva a una instalación y, aunque no era necesario que físicamente estuvera ubicado en la misma  instalación, la fiabilidad del sistema depende mucho de la fiabilidad del equipo donde este instalado el Servidor.

La versíon V1 está diseñada para intalarse en cualquier equipo en la nube y pude funcionar de forma exclusiva para una instalación o para varias instalaciones, además, puede funcionar como servidor único  de forma independiente o en modo **multiservidor** formando  parte de una red de servidores funcionando con memoria compartida y con reparto de carga.

En esta versión ya no se utiliza base de datos externa, no es necesario instalar **Mysql** ni **Apache** ni otras muchas cosas, en realidad, para que funcione el servidor, solo se necesita **Java** y el  fichero **.jar** con el código del servidor.

Inicialmente, la instalación se hizo de esa forma, más tarde, utilizamos **Docker** para ejecutar el servidor. No es este un sitio donde vaya a explicar las bondades de **Docker** pero lo único que puedo decir es que no se como he podido vivir tantos años sin utilizar **Docker**.

Al igual que en la descripción de la V0,  se deben describir las funcionalidades de la V1, las distintas instalaciones y como arrancar el servidor, pero antes, haremos una breve descripción del funcionamiento en modo **multiservidor**

## Principio de funcionamiento de Serverpic V1 en modo multiservidor <a name="id2"></a>

La fiabilidad en este modo de funcionamiento es muy superior a la de la versión V0. Disponer de una red de servidores hace posible que la 'caida' de uno de ellos no afecte al servici pero, ¿ como funciona el modo **multiservidor** ?

En la siguiente figura se puede ver un sistema de este tipo


![RedServidores_1.png](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/oBVVenZ9S4eO0ka5rGmd_RedServidores_1.png)


El funcionamiento es el siguiente.

Los dispositivos de una instalación se conectan a un **mundo** de serverpic a traves del router de la instalación. El **mundo** se utiliza para separar instalaciones de distintos usuarios, en este caso, el mundo sería **micasa.jusaba.es**, cuando la red de servidores se pone en fucnionamiento, uno de ellos lidera el arranque ( arranque memoria compartida, dns, ... ), imaginemos que en nuestra instalación el lider es  Serverpic_1.com. En el arranque, Serverpic_1.com le dice al servidor DNS que dirija el tráfico de **micasa.jusaba.es** hacia el. Cada cierto tiempo, el sistema va cambiando el servidor que atiende a  **micasa.jusaba.es**, el siguiente será Serverpipc_2.com, luego Serverpic_3.com y así sucesivamante hasta llegar a Serverpic_N.com, una vez alcanzado el último servidor, vuelve a repetirse el ciclo empezando por Serverpic_1.com de forma que, los dispositivos,  cuando vayan arrancando se irán conectando al servidor al que en ese momento el servidor de DNS está apuntando sin importar a cual se ha conectado por que al compartir la memoria, de cara a los dispositivos simepre se conectan a un servidor **micasa.jusaba.es**.

Si un servidor cayera, el sistema se entera y excluye su dirección de la rotación de servidores en las DNS, todos los dispositivos conectados a ese servidor, perderán la conexión y pasado unos segundos intentarán reconectar a  **micasa.jusaba.es** y el Servidor DNS los conducirá hacia el servidor que en ese momento este esperando conexiones.

Como se dijo este sistema ofrece una alta fiabilidad si bien, se complica bastante el funcionamiento interno y relentiza ligeramente el sistema.

Este sistema, además de ser multiservidor tambien puede ser multiusuario. Puede atender más e una isntalación como si furan isntalaciones independientes que no tuvieran nada que ver entre ellas, otra ventaja respecto a la V0.

En la siguiente figura se presenta un sistema multiservidor con atendiendo a varias instalaciones.

![RedServidores_2.png](https://s3-ap-northeast-1.amazonaws.com/torchpad-production/wikis/13242/z4SgBybKTlyJFPYojooo_RedServidores_2.png)



## Funcionalidades de Serverpic V1 📋 <a name="id3"></a>
Como en V0. la funcionalidad más importante es  **mensaje** pero hay otras que son muy interesantes y muy prácticas.
En la siguiente tabla se describen las distintas funcionalidades de V1, algunas son evidentes y otras no se pueden entender sin conocer como funcionan los dispositivos. Cuando se trate el tema de los dispositivos se explicarán y se entenderán esas funcionalidades.

```
	broadcast.- Envia un texto a todos los clientes
  
									broadcast-:-Hola
                  
	firmwares.- Devuelve un listado de los ultimos firmwares instalados en los dipositivos 
	
  								firmwares
 
	            Esta funcionalidad aprovecha la información que proporcionan los dispositivos sobre el
	            firmware que tienen instalado
              
	info.-     	Envia un broadcast de #Info. 
  
									info
                  
	            Los dispositivos, cuando reciben la orden #info, responden con información particular
	            del mismo
              
	Latido.-   	El Servidor devuelve Ok cuando un dispositivo le manda Latido
  
	               Opciones
    	              Latido
    	              Latido-:-vFirmware.- Manda al servidor la versión de firmware instalada

	lista.- 	Crea lista de broadcast de dispositivos

	            Opciones
    	              lista-:-anadir-:-Nombre Lista-:-Nombre Usuario.- Añade un usuario a la lista
    	              lista-:-eliminar-:-Nombre Lista-:-Nombre Usuario.- Borra un usuario de la lista
    	              lista-:-info	.- Devuleve relación de listas creadas
                    lista-:-eliminar-:-Nombre Lista.- Elimina una lista
                    
	mensaje.-	Envia un mensaje a un cliente. El cliente recibe el texto del mensaje precedido por el
	            remitente
              
					Julian manda      mensaje-:-Pepe-:-Hola
					Pepe recibe       Julian-:-Hola
          
	nombre.- 	Devuelve el nombre del servidor al que esta conectado el dispositivo         
  
	push.-     	Manda un pushover
  
							push-:-Token-:-Usuario-:-Dispositivo-:-Titulo-:-Mensaje-:-Sonido
              
	            Este comando utiliza la aplicación Pushover para mandar mensajes emergentes
	            a teléfonos, tablets, ....
	            Token y Usuario son parametros que te proporciona la aplicación cuando te
	            suscribes              

	servidores.-Devuelve una lista de los servidores en red con el numero de clientes conectqdos a cada
	            uno de ellos
              
									servidores
                  
	usuarios.- 	Devuelve una lista de todos los clientes conectados indicando a que servidor esta
	            conectado cada uno de ellos  

									usuarios
```
Serverpic V1 ademas de las funcionalidades via socket tiene otras funcionalidades via web. Estas otras funcionalidades se han creado para facilitar al acceso a Serverpic via web y poder implantar controles desde **html** y **js**

Las facilidades disponibles son las siguientes:

``` 
picserver.jusaba.es:1302/upload.html.- Formulario para subir un firmware de dispositivo. 
		El firmware debe denominarse con el formato NombreIno_VersionIno, por ejemplo SonOffS20_92.bin.
		Cuando Serverpic recibe esto, manda un broadcast de actualización de firmware con el nombre del
		nuevo frimware y todos lo sdispositivos con ese software se actualizarán a la nueva versión.
    
picserver.jusaba.es:1302/estado.- Dibuja un grafico con la red de servidores y los dispositiovs conectados

picserver.jusaba.es:1302/dispositivos/.- Se recibe un JSON con información de los dispositivos conectados
		La estructura de la información de cada usuario es la siguiente
				{
						"dateTime": "2020-03-17T19:59:16.223+0000",
						"user": "sonoff2",
						"hostname": "salmeo_com",
						"ultimoValor": "Off",
						"lastCommand": "Latido",
						"version": "92"
				}
		Como alternativa, si se el solicita un solo cliente, se obtendran los datos solo de ese cliente
						http://picserver.jusaba.es:1302/dispositivos/sonoff2   

picservertest.jusaba.es:2001/usuario/<Destinatario>?mensaje=Orden.- Manda el mensaje <orden> al <Destinatario>
```
## Instalación de Serverpic V1 🛠️ <a name="id4"></a>

Esta versión tiene más opciones de instalación que la V0. Como que puede funcionar con **Docker** o sin el, ya se dan dos opciones de instalación y, dentro de cada una de ellas además, se puede optar por insyalación manual y automática.

### Instalación manual de Serverpic V1 sin Docker <a name="id5"></a>

Par la instalación manual, se debe proceder tal como se describe en el bloque **Puesta en marcha** de la [[Instalación manual V0|Serverpic/InstalacionManual]].

Una vez preparada la Raspberry ( o cualquier otro Hardware ), para instalar Serverpic V1, primero instalaremos Java

	sudo apt install default-jdk
  
Comprobaremos que se ha instalado identificando la versión

	java -version

Una vez instalado Java, vamos  a descarhgar el fichero **jar** de Serverpic V1 

	cd /home/pi
	mkdir Serverpic
	cd Serverpic
	curl -O -J -L 'https://julian60:Jusaba2408!@bitbucket.org/oscarsm91/serverpic/downloads/serverpic-0.0.1-SNAPSHOT.jar'
  
Ahora será necesario crearle un servicio para que arranque de forma automática cuando se ponga en marcha el equipo pero, como que hay varias opciones de arranque, se deja el detalle para el apartado  [Ejecución de Serverpic V1](#id1), no obstante, para arrancarlo de forma inmediata y empezar a utilizar, existe un paquete **deb** que crea un servicio para el servidor de forma que arranca de forma automatica cuando se inica el equipo.
Para bajar y descomprimir el paquete teclear

	cd /home/pi		
	wget https://www.dropbox.com/s/s4dasjbtphrmzuu/ServerpicV1.deb
	sudo dpkg -i ServerpicV1.deb
  
Ya esta creado el servicio para gestionar Serverpic. Los coamndo disponibles del servicio son

	sudo service serverpic start
	sudo service serverpic stop
	sudo service serverpic restar

Así mismo, el paquete, crea un alias de forma que para ver la actividad del servidor se debe teclear

	serverpiclog
  
Cuando se desee salir del monitoreo del servidor se debe pulsar ** Ctrl + Z **


### Instalación manual de Serverpic V1 con Docker <a name="id6"></a>

Antes de describir esta instalación es necesario justificar el uso de **Docker**.
Como se decía anteriormente, no se va a hacer ningún tutoria ( por lo menos de momento ) de **Docker** en esta documentación pero si que se van a enumerar las ventajas de usar esta tecnología.

	- Con Docker, Serverpic es multiplataforma
	- Se simplifica la instalación y es independiente de la plataforma
	- Permite actualización automática cuando se publica una nueva versión
	- Se pueden tener varios servidores independientes en una misma máquina
  
Una vez enumeradas las bondades de utilizar **Docker** vamos a proceder a la instalación manual.

En primer lugar, al igual que en el apartado anterior, se procederá según se describe en el bloque **Puesta en marcha** de la [[Instalación manual V0|Serverpic/InstalacionManual]].

Una vez preparado el equipo, se intalará **Docker**

	sudo apt-get update -y
	sudo curl -fsSL https://download.docker.com/linux/debian/gpg | sudo apt-key add -	
	sudo curl -sSL https://get.docker.com/ | sh
	sudo groupadd docker
	sudo usermod -aG docker pi

Ya tenemos instalado **Docker** y además se ha instalado como servicio, para habilitarlo ( el servicio )

	sudo systemctl enable docker
	sudo systemctl start docker

**Docker** ya está instalado, habilitado su servicio y arrancado

Ahora instalaremos **Docker compose**, un paquete que, si bien no es necesario, dará mucho juego para instalaciones de otros contenedores de esta tecnología.

La instalación se hace algo larga pero es muy sencilla

	sudo apt install -y python python-pip libffi-dev python-backports.ssl-match-hostname
	sduo pip install docker-compose
  
Ya tenmos instaldo **Docker compose**, ahora es necesario reiniciar el equipo 

	sudo reboot -h now
  
Ahora que tenemos Docker, instalar Serverpic es muy sencillo. Aunque las opciones de arranque se describen en  [Ejecución de Serverpic V1](#id1), un ejemplo de instalación/arranque de un servidor en su forma más básica sería:

	docker run --name serverpic -p 1301:7000 -p 1302:7001 -d  --log-driver json-file --log-opt max-size=10m  jusaba/serverpic:latest -d

Esto arranca un contenedor llamado serverpic que escucha en los puertos 1301 ( servidor ) y 1302 ( web ) generando un fichero log de un maximo de 10 megas con la imagen jusaba/serverpic:latest

Aprovechando las bondades de **Docker**, podríamos tener en la misma máquina otro servidor identico cambiando unicamente los puertos de escucha y el nombre

	docker run --name serverpic_1 -p 1303:7000 -p 1304:7001 -d  --log-driver json-file --log-opt max-size=10m  jusaba/serverpic:latest -d

### Instalación automática de Serverpic V1 <a name="id7"></a>
  En lo que respecta a la instalación, por último, abordaremos una instalación automatica similar a la de la V0.
  
  La primera parte del fichero de configuración es identica a la utilizada en el de la V0. Tras los datos de preparación de la Raspberry ( Password, IP's, SSH, ... ) se procede a intalar el servidor y en función de una variable del fichero de configuración se instalará con Docker o directamente

Primero, tal como en la versión V0,  en /home/pi descargaremos los dicheros **Instalacion.sh** y **configuracion**

	cd /home/pi
	wget https://www.dropbox.com/s/ub3vvi2ttf17cze/Instalacion.sh
	wget https://www.dropbox.com/s/08n2hgkhm4xjd8g/configuracion

El fichero **configuracion** se debe editar con los datos con los que precisamos para nuestra instalación 

	nano configuracion

Si se desea instalar con Dockker se debe respetar la línea **Docker=Si**, en caso contrario, se instalara Java y el fichero **jar** de Serverpic.

Una vez realizados todos los cambios deseados los guardamos  pulsando **Ctrl + O** y salimos con **Ctrl + X**

A continuación se muestra el contenido del fichero **configuración** con los parametros por defecto.
Las líneas que empiezan con **#** son comentarios que explican brevemente cada uno de los parametros. Los parametros a modificar se encuentran en las líneas que no empiezan por **#** 
```  
#----------------------------------------------------------
#Raspberry
#Cambia el password de la raspberry
#Si se quita esta linea, se mantendra el password existente
#----------------------------------------------------------
PasswordRasp=Serverpic2408
#----------------------------------------------------------
#SSH
#Cambia el puerto ssh
#Si se quita esta linea, se mantendra el puerto existente
#----------------------------------------------------------
PortSSH=1322
#----------------------------------------------------------
# Red STA 
# Este modo es STA, tanto etho como wlan0 se pueden conectar
# a una red existente
# Si se omite NombreSSID o PasswordSSID no se modifica la
# SSID existente en la raspberry
# Si se pone una direccion en IPETH0, se pondra una ip 
# estatica en eth0. Si se omite se mantendra 
# la configuracion para eth0
# Si se pone una direccion en IPWLAN0, se pondra una ip 
# estatica en wlan. Si se omite se mantendra 
# la configuracion para wlan0
# NO SE COMPRUEBAN POSIBLES ERRORES DE ASIGNACION
# LA RED DEBE SER 192.168.1.X
#----------------------------------------------------------
ModoRed=STA
NombreSSID=MiWifi
PasswordSSID=MiPassword
IPETH0=192.168.1.13
IPWLAN0=192.168.1.23
#----------------------------------------------------------
# Docker
# Se instala Docker, si se omite la linea Docker=Sim, se 
# hace una instalación sin Docker
#----------------------------------------------------------
Docker=Si
```

Ahora, una vez la instalación finalizada, es necesario reiniciar el equipo y conectarse a el con la IP con la que lo hemos configurado

	sudo reboot -h now

### Ejecución de Serverpic V1 ⚙️ <a name="id8"></a> ###

La ejecución de ServerpicV1 admite bastantes posibilidades. Como que ademas, se puede instalar con o sin Docker, las posibilidades se multiplican por dos.

Vamos a tratar por separado las dos modalidades de funcionameinto.

### Ejecución de Serverpic V1 sin Docker <a name="id9"></a>

Para ejecutar el **jar** de Serverpic directamente

	java -jar serverpic-0.0.1-SNAPSHOT.jar --server.port=1302 --serverpic.puerto=1301 --spring.profiles.active="mq,dns"

Los parametros utilizados son los siguiente

	--server.port.- Puerto donde escucha el servidor html. Si se omite su valor es 7001
	--serverpic.puero.- Puerto donde escucha serverpic. Si se omite, su valor es 7000
	--spring.profiles.active
  
Como que en la instalación se tuvo en cuenta asignarle un servicio para su arranque automático, si se quieren variar los parametros se debe editar el fichero **/usr/local/bin/serverpic**

	nano /usr/local/bin/serverpic
  
Se debe modificar la linea que llama a Serverpic tanto en la opción **start** como en la opción **restart** 
Una vez modificado, salvar los cambios con **Ctrl + O** y salimos con **Ctrl + X**

### Ejecución de Serverpic V1 con Docker <a name="id10"></a>

Para la ejecución con Docker, se debe arrancar el contenedor de Serverpic.
El contenedro necesita algún parametro más de los descritos en el apartado anterior. El arranque sería de la siguiente forma

	docker run --name serverpic_test -p 2000:7000 -p 2001:7001 -d -e "SPRING_PROFILES_ACTIVE=mq,dns" -e "MUNDO=picservertest" --hostname salmeo_com --log-driver json-file --log-opt max-size=10m  jusaba/serverpic:latest -d

La descripción de los parámtros es la siguiente

	--server.port.- Puerto donde escucha el servidor html. Si se omite su valor es 7001
	--serverpic.puero.- Puerto donde escucha serverpic. Si se omite, su valor es 7000
	--MUNDO.- MUNDO en el que se quiere el servidor, podria ser uno por usuario o por instalacion
	--spring.profiles.active.- Variable para habilitar Serverpic como multiservidor
	--log-driver.- Utiliza un controlador de registro diferente al predeterminado de Docker (json)
	--log-opt max-size.- Longitud máxima del fichero de registro